# Roadmap — what to build next, in order

Phase 1 (done in this pass): architecture, DB schema, auth + 2FA, product
catalog, cart/wishlist, multi-vendor checkout, order tracking, vendor
application/dashboard/withdrawals, reviews, admin core, support tickets +
live chat transport, homepage UI, Docker/Nginx/CI scaffolding.

Phase 2 — payments (highest priority, blocks real checkout):
- Stripe: PaymentIntent creation in `orderService.checkout`, webhook
  handler to mark `Payment.status = PAID` and advance `Order.status`.
- PayPal: Orders v2 API integration, capture-on-approve flow.
- Bank transfer: generate reference number + instructions page.
- Crypto: integrate a payment processor (e.g. Coinbase Commerce) for
  invoice generation and webhook confirmation.

Phase 3 — vendor & admin panels (UI):
- `/vendor/dashboard` — analytics charts, product table, order queue.
- `/vendor/products/new` — product form wired to `POST /products`.
- `/admin` — the panels the API already supports: user/vendor tables,
  category/banner/CMS editors, security log viewer.

Phase 4 — commerce polish:
- Multi-currency: FX rate service + display conversion (store canonical
  price in vendor's currency, convert at render time).
- Multi-language: `next-intl` or `next-i18next`, extract all UI strings.
- Coupon UI in checkout, order confirmation emails via `EmailTemplate`.

Phase 5 — trust & ops:
- reCAPTCHA verification wired into `/auth/register` and `/auth/login`.
- S3 upload signing endpoint for product images and chat attachments.
- Automated backups + admin-triggered restore flow.
- Email templates for order confirmation, shipping updates, vendor
  approval/rejection, withdrawal processed.

Each phase is additive — nothing in Phase 1 needs to change to build the
rest.
