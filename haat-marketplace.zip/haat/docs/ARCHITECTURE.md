# Architecture

## Overview

```
Browser ──HTTPS──▶ Nginx ──▶ Next.js (apps/web)   [SSR storefront, vendor & admin panels]
                       └──▶ Express API (apps/api) [REST + WebSocket chat]
                                    └──▶ PostgreSQL (via Prisma)
                                    └──▶ S3-compatible object storage (product images, chat attachments)
```

## Why this stack

- **Next.js App Router** — SSR for SEO-critical pages (product, category, vendor
  storefronts) with client components only where interactivity is needed
  (search autocomplete, cart, theme toggle).
- **Express + Prisma** — a REST API kept deliberately boring and explicit:
  every route validates input with `zod`, every DB call goes through Prisma's
  parameterized query builder (no raw SQL), and role checks are middleware,
  not scattered `if` statements.
- **PostgreSQL** — relational integrity matters here: an order references a
  user, N order items, N vendor groups, and a payment — all of which must
  commit atomically (see `orderService.checkout`, which wraps the whole
  flow in a `prisma.$transaction`).

## Multi-vendor order model

A single customer order (`Order`) can contain products from multiple
vendors. We split it into `OrderVendorGroup` rows — one per vendor — each
carrying that vendor's subtotal, platform commission, and payout. This is
what powers vendor-side order management, earnings reports, and withdrawal
requests without vendors ever seeing each other's data.

## AuthN/AuthZ

- Short-lived JWT access tokens (15 min) in the `Authorization` header.
- Long-lived refresh tokens in an `httpOnly`, `Secure`, `SameSite=Strict`
  cookie, rotated on every use (old token revoked, new one issued) —
  limits the blast radius of a stolen refresh token.
- TOTP-based two-factor auth (`otplib`), enabled per-user.
- `requireRole(...)` middleware enforces RBAC on every sensitive route;
  fine-grained permissions (`Permission` / `UserPermission` models) are in
  the schema for admin sub-roles (e.g. a support agent who can also
  moderate reviews) — wire these into `requireRole` as the admin UI grows
  past coarse roles.

## CSRF

State-changing API calls require a Bearer access token that a cross-site
page cannot read or attach automatically, which is the primary CSRF
defense for the JSON API surface. The one cookie-only endpoint
(`/api/auth/refresh`) relies on `SameSite=Strict` + `Secure`. If the
frontend later adds any cookie-authenticated form POST (e.g. a legacy
webhook receiver), wire in the `csrf-csrf` double-submit token already
listed as a dependency.

## Real-time chat

A lightweight `ws` server is mounted on the same HTTP server at `/ws/chat`,
authenticated via the same JWT access token passed as a query param. It's
a thin push layer — messages are always persisted via the REST endpoint
first (`POST /api/support/tickets/:id/messages`), then broadcast. This
keeps chat history durable and simple to paginate, and the WS layer
replaceable (e.g. with a managed pub/sub service) without touching the
data model.

## Performance

- Route-level `select`/`include` in Prisma queries to avoid over-fetching.
- `compression` middleware + Nginx gzip.
- Next.js automatic image optimization for product photos (wire product
  images through `next/image` once real S3 URLs are in place).
- Pagination on every list endpoint (`page`/`pageSize`), defaulting to
  small page sizes to keep payloads and Lighthouse-relevant TTFB low.

## What's scaffolded vs. built out

Fully wired: auth (+2FA), product CRUD, cart, wishlist, checkout with
multi-vendor split and coupon logic, order tracking, vendor
application/approval/dashboard/withdrawals, reviews, admin analytics/user
management/categories/banners/CMS/security logs, support tickets + live
chat.

Stubbed with typed routes and `TODO` markers, ready to fill in: real
payment gateway calls (Stripe/PayPal/crypto SDKs), email sending against
the `EmailTemplate` model, S3 upload signing, shipping-rate calculation,
and reCAPTCHA verification. See `docs/ROADMAP.md`.
