# Haat — Multi-Vendor Marketplace

> "Everything, from everyone." A premium, production-grade multi-vendor e-commerce platform.

Original platform built from scratch — no cloned themes, no copied storefronts. Own branding, own design system, own codebase.

## Monorepo layout

```
haat/
├── apps/
│   ├── web/            # Next.js 14 (App Router) storefront + vendor + admin panels
│   └── api/             # Express + TypeScript REST API
├── packages/
│   └── db/              # Prisma schema (PostgreSQL), migrations, seed data
├── nginx/                # Reverse proxy config for production
├── docs/                 # Architecture, API reference, deployment guide
├── .github/workflows/    # CI/CD pipeline
└── docker-compose.yml
```

## Quick start (local dev)

```bash
cp .env.example .env
docker compose up -d db          # start Postgres
cd packages/db && npx prisma migrate dev && npx prisma db seed
cd apps/api && npm install && npm run dev     # http://localhost:4000
cd apps/web && npm install && npm run dev     # http://localhost:3000
```

## Build status

This is Phase 1 of the build: architecture, database schema, auth, and the
core commerce loop (products → cart → checkout → orders) are fully wired.
Admin/vendor dashboards, live chat, and payment gateway integrations are
scaffolded with typed routes and TODOs — see `docs/ROADMAP.md` for the
module-by-module build order so we can keep extending this together.

See `docs/ARCHITECTURE.md`, `docs/API.md`, and `docs/DEPLOYMENT.md` for details.
