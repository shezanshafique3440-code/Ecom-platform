import Stripe from 'stripe';
import crypto from 'crypto';
import { env } from '../config/env';
import { prisma } from '../config/prisma';
import { ApiError } from '../middleware/errorHandler';

const stripe = env.stripe.secretKey ? new Stripe(env.stripe.secretKey) : null;

function requireOrderOwnedBy(orderId: string, userId: string) {
  return prisma.order.findFirstOrThrow({ where: { id: orderId, userId } }).catch(() => {
    throw new ApiError(404, 'Order not found');
  });
}

// ---------------- Stripe ----------------

export async function createStripeIntent(orderId: string, userId: string) {
  if (!stripe) throw new ApiError(503, 'Stripe is not configured on this server');
  const order = await requireOrderOwnedBy(orderId, userId);

  const intent = await stripe.paymentIntents.create({
    amount: Math.round(Number(order.grandTotal) * 100),
    currency: order.currency.toLowerCase(),
    metadata: { orderId: order.id, orderNumber: order.orderNumber },
    automatic_payment_methods: { enabled: true },
  });

  await prisma.payment.update({
    where: { orderId: order.id },
    data: { providerRef: intent.id },
  });

  return { clientSecret: intent.client_secret };
}

export function constructStripeEvent(rawBody: Buffer, signature: string): Stripe.Event {
  if (!stripe) throw new ApiError(503, 'Stripe is not configured on this server');
  return stripe.webhooks.constructEvent(rawBody, signature, env.stripe.webhookSecret);
}

export async function handleStripeEvent(event: Stripe.Event): Promise<void> {
  if (event.type === 'payment_intent.succeeded') {
    const intent = event.data.object as Stripe.PaymentIntent;
    const orderId = intent.metadata.orderId;
    if (orderId) await markOrderPaid(orderId, intent.id);
  }
  if (event.type === 'payment_intent.payment_failed') {
    const intent = event.data.object as Stripe.PaymentIntent;
    const orderId = intent.metadata.orderId;
    if (orderId) await markOrderPaymentFailed(orderId);
  }
}

// ---------------- PayPal ----------------

async function getPayPalAccessToken(): Promise<string> {
  const basicAuth = Buffer.from(`${env.paypal.clientId}:${env.paypal.clientSecret}`).toString(
    'base64',
  );
  const res = await fetch(`${env.paypal.apiBase}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basicAuth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new ApiError(502, 'Failed to authenticate with PayPal');
  const data = (await res.json()) as { access_token: string };
  return data.access_token;
}

export async function createPayPalOrder(orderId: string, userId: string) {
  if (!env.paypal.clientId) throw new ApiError(503, 'PayPal is not configured on this server');
  const order = await requireOrderOwnedBy(orderId, userId);
  const accessToken = await getPayPalAccessToken();

  const res = await fetch(`${env.paypal.apiBase}/v2/checkout/orders`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [
        {
          reference_id: order.orderNumber,
          custom_id: order.id,
          amount: {
            currency_code: order.currency,
            value: Number(order.grandTotal).toFixed(2),
          },
        },
      ],
      application_context: {
        return_url: `${env.webAppUrl}/checkout/paypal/return`,
        cancel_url: `${env.webAppUrl}/checkout/paypal/cancel`,
      },
    }),
  });
  if (!res.ok) throw new ApiError(502, 'Failed to create PayPal order');
  const data = (await res.json()) as { id: string; links: { rel: string; href: string }[] };

  await prisma.payment.update({ where: { orderId: order.id }, data: { providerRef: data.id } });

  const approvalUrl = data.links.find((l) => l.rel === 'approve')?.href;
  return { paypalOrderId: data.id, approvalUrl };
}

export async function capturePayPalOrder(paypalOrderId: string) {
  const accessToken = await getPayPalAccessToken();
  const res = await fetch(
    `${env.paypal.apiBase}/v2/checkout/orders/${paypalOrderId}/capture`,
    { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` } },
  );
  if (!res.ok) throw new ApiError(502, 'Failed to capture PayPal order');
  const data = (await res.json()) as {
    status: string;
    purchase_units: { custom_id: string }[];
  };

  const orderId = data.purchase_units[0]?.custom_id;
  if (data.status === 'COMPLETED' && orderId) {
    await markOrderPaid(orderId, paypalOrderId);
  }
  return data;
}

// ---------------- Crypto (Coinbase Commerce) ----------------

export async function createCryptoCharge(orderId: string, userId: string) {
  if (!env.crypto.coinbaseApiKey) throw new ApiError(503, 'Crypto payments are not configured');
  const order = await requireOrderOwnedBy(orderId, userId);

  const res = await fetch('https://api.commerce.coinbase.com/charges', {
    method: 'POST',
    headers: {
      'X-CC-Api-Key': env.crypto.coinbaseApiKey,
      'X-CC-Version': '2018-03-22',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: `Order ${order.orderNumber}`,
      description: `Haat marketplace order ${order.orderNumber}`,
      pricing_type: 'fixed_price',
      local_price: { amount: Number(order.grandTotal).toFixed(2), currency: order.currency },
      metadata: { orderId: order.id },
      redirect_url: `${env.webAppUrl}/orders/${order.id}`,
    }),
  });
  if (!res.ok) throw new ApiError(502, 'Failed to create crypto charge');
  const data = (await res.json()) as { data: { id: string; hosted_url: string } };

  await prisma.payment.update({
    where: { orderId: order.id },
    data: { providerRef: data.data.id },
  });

  return { chargeId: data.data.id, hostedUrl: data.data.hosted_url };
}

export function verifyCoinbaseSignature(rawBody: Buffer, signature: string): boolean {
  const computed = crypto
    .createHmac('sha256', env.crypto.coinbaseWebhookSecret)
    .update(rawBody)
    .digest('hex');
  return crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(signature));
}

export async function handleCoinbaseEvent(body: {
  event: { type: string; data: { metadata?: { orderId?: string }; id: string } };
}): Promise<void> {
  const { type, data } = body.event;
  const orderId = data.metadata?.orderId;
  if (!orderId) return;
  if (type === 'charge:confirmed') await markOrderPaid(orderId, data.id);
  if (type === 'charge:failed') await markOrderPaymentFailed(orderId);
}

// ---------------- Bank transfer ----------------

export async function getBankTransferInstructions(orderId: string, userId: string) {
  const order = await requireOrderOwnedBy(orderId, userId);
  return {
    reference: order.orderNumber,
    amount: order.grandTotal,
    currency: order.currency,
    beneficiary: env.bankTransfer.accountName,
    accountNumber: env.bankTransfer.accountNumber,
    iban: env.bankTransfer.iban,
    swift: env.bankTransfer.swift,
    bankName: env.bankTransfer.bankName,
    note: 'Include the reference in your transfer memo. Orders are confirmed once funds clear — usually 1-3 business days.',
  };
}

// ---------------- Shared order state transitions ----------------

async function markOrderPaid(orderId: string, providerRef: string): Promise<void> {
  await prisma.$transaction([
    prisma.payment.update({
      where: { orderId },
      data: { status: 'PAID', providerRef },
    }),
    prisma.order.update({
      where: { id: orderId },
      data: { status: 'CONFIRMED' },
    }),
    prisma.orderTrackingEvent.create({
      data: { orderId, status: 'CONFIRMED', note: 'Payment received' },
    }),
  ]);
}

async function markOrderPaymentFailed(orderId: string): Promise<void> {
  await prisma.payment.update({ where: { orderId }, data: { status: 'FAILED' } });
  await prisma.orderTrackingEvent.create({
    data: { orderId, status: 'PENDING', note: 'Payment failed — customer may retry' },
  });
}
