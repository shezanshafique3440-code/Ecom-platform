import { authenticator } from 'otplib';
import { prisma } from '../config/prisma';
import { ApiError } from '../middleware/errorHandler';
import {
  hashPassword,
  verifyPassword,
  signAccessToken,
  generateRefreshToken,
  refreshTokenExpiry,
} from '../utils/auth';

interface RegisterInput {
  email: string;
  password: string;
  fullName: string;
}

export async function registerUser({ email, password, fullName }: RegisterInput) {
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) throw new ApiError(409, 'An account with this email already exists');

  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({
    data: { email, passwordHash, fullName },
  });
  return sanitizeUser(user);
}

export async function loginUser(email: string, password: string, totpCode?: string) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new ApiError(401, 'Invalid email or password');

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) throw new ApiError(401, 'Invalid email or password');

  if (user.twoFactorEnabled) {
    if (!totpCode) throw new ApiError(401, 'Two-factor code required');
    const secret = user.twoFactorSecret ?? '';
    const ok = authenticator.check(totpCode, secret);
    if (!ok) throw new ApiError(401, 'Invalid two-factor code');
  }

  const accessToken = signAccessToken({ sub: user.id, role: user.role });
  const refreshToken = generateRefreshToken();
  await prisma.refreshToken.create({
    data: { token: refreshToken, userId: user.id, expiresAt: refreshTokenExpiry() },
  });

  return { user: sanitizeUser(user), accessToken, refreshToken };
}

export async function rotateRefreshToken(oldToken: string) {
  const record = await prisma.refreshToken.findUnique({ where: { token: oldToken } });
  if (!record || record.revoked || record.expiresAt < new Date()) {
    throw new ApiError(401, 'Refresh token invalid or expired');
  }
  await prisma.refreshToken.update({ where: { id: record.id }, data: { revoked: true } });

  const user = await prisma.user.findUniqueOrThrow({ where: { id: record.userId } });
  const accessToken = signAccessToken({ sub: user.id, role: user.role });
  const refreshToken = generateRefreshToken();
  await prisma.refreshToken.create({
    data: { token: refreshToken, userId: user.id, expiresAt: refreshTokenExpiry() },
  });
  return { accessToken, refreshToken };
}

export async function enableTwoFactor(userId: string) {
  const secret = authenticator.generateSecret();
  await prisma.user.update({ where: { id: userId }, data: { twoFactorSecret: secret } });
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const otpauthUrl = authenticator.keyuri(user.email, 'Haat', secret);
  return { secret, otpauthUrl };
}

export async function confirmTwoFactor(userId: string, code: string) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const ok = authenticator.check(code, user.twoFactorSecret ?? '');
  if (!ok) throw new ApiError(400, 'Invalid verification code');
  await prisma.user.update({ where: { id: userId }, data: { twoFactorEnabled: true } });
  return { enabled: true };
}

function sanitizeUser<T extends { passwordHash: string; twoFactorSecret: string | null }>(
  user: T,
) {
  const { passwordHash, twoFactorSecret, ...safe } = user;
  return safe;
}
