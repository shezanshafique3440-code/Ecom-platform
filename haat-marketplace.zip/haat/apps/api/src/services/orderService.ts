import { prisma } from '../config/prisma';
import { ApiError } from '../middleware/errorHandler';
import crypto from 'crypto';

interface CheckoutInput {
  userId: string;
  shippingAddressId?: string;
  couponCode?: string;
  paymentMethod: 'STRIPE' | 'PAYPAL' | 'BANK_TRANSFER' | 'CRYPTO' | 'COD';
}

function generateOrderNumber(): string {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `HAAT-${stamp}-${rand}`;
}

export async function checkout({ userId, shippingAddressId, couponCode, paymentMethod }: CheckoutInput) {
  const cartItems = await prisma.cartItem.findMany({
    where: { userId },
    include: { product: true },
  });
  if (cartItems.length === 0) throw new ApiError(400, 'Cart is empty');

  // Validate stock up front so we fail fast before touching payment.
  for (const item of cartItems) {
    if (item.product.stock < item.quantity) {
      throw new ApiError(409, `Insufficient stock for "${item.product.title}"`);
    }
  }

  let discountTotal = 0;
  let coupon = null;
  if (couponCode) {
    coupon = await prisma.coupon.findUnique({ where: { code: couponCode } });
    if (!coupon || !coupon.active) throw new ApiError(400, 'Invalid or expired coupon');
    if (coupon.expiresAt && coupon.expiresAt < new Date()) {
      throw new ApiError(400, 'Coupon has expired');
    }
    if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
      throw new ApiError(400, 'Coupon usage limit reached');
    }
  }

  const subtotal = cartItems.reduce(
    (sum, item) => sum + Number(item.product.basePrice) * item.quantity,
    0,
  );
  if (coupon) {
    if (coupon.minSpend && subtotal < Number(coupon.minSpend)) {
      throw new ApiError(400, `Coupon requires a minimum spend of ${coupon.minSpend}`);
    }
    discountTotal =
      coupon.type === 'PERCENT' ? subtotal * (Number(coupon.value) / 100) : Number(coupon.value);
  }

  const shippingTotal = 0; // TODO: real shipping calculation by vendor/zone
  const grandTotal = Math.max(subtotal - discountTotal + shippingTotal, 0);

  // Group items by vendor for payout/commission accounting.
  const byVendor = new Map<string, typeof cartItems>();
  for (const item of cartItems) {
    const list = byVendor.get(item.product.vendorId) ?? [];
    list.push(item);
    byVendor.set(item.product.vendorId, list);
  }

  const order = await prisma.$transaction(async (tx) => {
    const createdOrder = await tx.order.create({
      data: {
        orderNumber: generateOrderNumber(),
        userId,
        subtotal,
        discountTotal,
        shippingTotal,
        grandTotal,
        couponCode: couponCode ?? null,
        shippingAddressId,
        status: 'PENDING',
        items: {
          create: cartItems.map((item) => ({
            productId: item.productId,
            vendorId: item.product.vendorId,
            quantity: item.quantity,
            unitPrice: item.product.basePrice,
            lineTotal: Number(item.product.basePrice) * item.quantity,
          })),
        },
      },
    });

    for (const [vendorId, items] of byVendor) {
      const vendor = await tx.vendor.findUniqueOrThrow({ where: { id: vendorId } });
      const vendorSubtotal = items.reduce(
        (s, i) => s + Number(i.product.basePrice) * i.quantity,
        0,
      );
      const commission = vendorSubtotal * (Number(vendor.commissionPct) / 100);
      await tx.orderVendorGroup.create({
        data: {
          orderId: createdOrder.id,
          vendorId,
          subtotal: vendorSubtotal,
          commission,
          payout: vendorSubtotal - commission,
        },
      });
    }

    // Decrement stock atomically within the same transaction.
    for (const item of cartItems) {
      await tx.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.quantity } },
      });
    }

    await tx.payment.create({
      data: {
        orderId: createdOrder.id,
        method: paymentMethod,
        amount: grandTotal,
        status: paymentMethod === 'COD' ? 'PENDING' : 'PENDING',
      },
    });

    if (coupon) {
      await tx.coupon.update({ where: { id: coupon.id }, data: { usedCount: { increment: 1 } } });
    }

    await tx.cartItem.deleteMany({ where: { userId } });

    await tx.orderTrackingEvent.create({
      data: { orderId: createdOrder.id, status: 'PENDING', note: 'Order placed' },
    });

    return createdOrder;
  });

  return order;
}
