import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';

// Helmet: sensible secure defaults (CSP, HSTS, no-sniff, frameguard, etc.)
export const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      connectSrc: ["'self'", env.corsOrigin],
    },
  },
  crossOriginResourcePolicy: { policy: 'cross-origin' },
});

export const corsPolicy = cors({
  origin: env.corsOrigin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
});

// General API rate limit — protects against brute force & scraping.
export const apiRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
});

// Tighter limiter specifically for auth endpoints (login/register/reset).
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts, please try again later.' },
});

// Basic defense-in-depth against XSS/NoSQL-injection style payloads in
// request bodies. Real input validation still happens per-route via zod
// schemas — this is a coarse net, not a substitute for it.
const DANGEROUS_KEY_PATTERN = /^\$|__proto__|constructor|prototype/i;

function stripDangerousKeys(obj: unknown): void {
  if (obj === null || typeof obj !== 'object') return;
  for (const key of Object.keys(obj as Record<string, unknown>)) {
    if (DANGEROUS_KEY_PATTERN.test(key)) {
      delete (obj as Record<string, unknown>)[key];
      continue;
    }
    stripDangerousKeys((obj as Record<string, unknown>)[key]);
  }
}

export function sanitizeInput(req: Request, _res: Response, next: NextFunction): void {
  stripDangerousKeys(req.body);
  stripDangerousKeys(req.query);
  stripDangerousKeys(req.params);
  next();
}

// Note on SQL injection: all DB access goes through Prisma's parameterized
// query builder (see packages/db) — no raw string-concatenated SQL is used
// anywhere in this API. If $queryRawUnsafe is ever needed, it must go
// through a security review first.
