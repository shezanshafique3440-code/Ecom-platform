import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate } from '../middleware/authenticate';
import { authRateLimit } from '../middleware/security';
import * as authService from '../services/authService';

export const authRouter = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  fullName: z.string().min(2),
  recaptchaToken: z.string().optional(),
});

async function logSecurityEvent(
  event: string,
  userId: string | null,
  req: { ip?: string; headers: Record<string, unknown> },
) {
  await prisma.securityLog.create({
    data: {
      event,
      userId: userId ?? undefined,
      ipAddress: req.ip,
      userAgent: (req.headers['user-agent'] as string) ?? undefined,
    },
  });
}

authRouter.post('/register', authRateLimit, async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);
    // TODO: verify input.recaptchaToken against Google reCAPTCHA siteverify
    // before creating the account, once RECAPTCHA_SECRET is configured.
    const user = await authService.registerUser(input);
    await logSecurityEvent('REGISTER', user.id, req);
    res.status(201).json({ user });
  } catch (err) {
    next(err);
  }
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
  totpCode: z.string().optional(),
});

authRouter.post('/login', authRateLimit, async (req, res, next) => {
  try {
    const { email, password, totpCode } = loginSchema.parse(req.body);
    const result = await authService.loginUser(email, password, totpCode).catch(async (err) => {
      await logSecurityEvent('LOGIN_FAIL', null, req);
      throw err;
    });
    await logSecurityEvent('LOGIN_SUCCESS', result.user.id, req);

    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });
    res.json({ user: result.user, accessToken: result.accessToken });
  } catch (err) {
    next(err);
  }
});

authRouter.post('/refresh', async (req, res, next) => {
  try {
    const token = req.cookies?.refreshToken;
    if (!token) return res.status(401).json({ error: 'No refresh token provided' });
    const result = await authService.rotateRefreshToken(token);
    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });
    res.json({ accessToken: result.accessToken });
  } catch (err) {
    next(err);
  }
});

authRouter.post('/logout', (req, res) => {
  res.clearCookie('refreshToken');
  res.json({ success: true });
});

authRouter.post('/2fa/enable', authenticate, async (req, res, next) => {
  try {
    const result = await authService.enableTwoFactor(req.user!.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

authRouter.post('/2fa/confirm', authenticate, async (req, res, next) => {
  try {
    const { code } = z.object({ code: z.string() }).parse(req.body);
    const result = await authService.confirmTwoFactor(req.user!.id, code);
    await logSecurityEvent('2FA_ENABLED', req.user!.id, req);
    res.json(result);
  } catch (err) {
    next(err);
  }
});
