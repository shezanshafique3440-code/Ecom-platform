import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';

export const reviewRouter = Router();

const reviewSchema = z.object({
  productId: z.string().uuid(),
  rating: z.number().int().min(1).max(5),
  title: z.string().optional(),
  body: z.string().optional(),
});

reviewRouter.post('/', authenticate, async (req, res, next) => {
  try {
    const input = reviewSchema.parse(req.body);

    // Verify purchase (basic anti-fraud: only buyers can review).
    const purchased = await prisma.orderItem.findFirst({
      where: { productId: input.productId, order: { userId: req.user!.id, status: 'DELIVERED' } },
    });
    if (!purchased) throw new ApiError(403, 'You can only review products you have purchased');

    const review = await prisma.review.create({ data: { ...input, userId: req.user!.id } });

    const agg = await prisma.review.aggregate({
      where: { productId: input.productId },
      _avg: { rating: true },
      _count: true,
    });
    await prisma.product.update({
      where: { id: input.productId },
      data: { avgRating: agg._avg.rating ?? 0, reviewCount: agg._count },
    });

    res.status(201).json({ review });
  } catch (err) {
    next(err);
  }
});

reviewRouter.get('/product/:productId', async (req, res, next) => {
  try {
    const reviews = await prisma.review.findMany({
      where: { productId: req.params.productId },
      include: { user: { select: { fullName: true, avatarUrl: true } } },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ reviews });
  } catch (err) {
    next(err);
  }
});

export const couponRouter = Router();

couponRouter.post('/validate', authenticate, async (req, res, next) => {
  try {
    const { code, subtotal } = z
      .object({ code: z.string(), subtotal: z.number().nonnegative() })
      .parse(req.body);
    const coupon = await prisma.coupon.findUnique({ where: { code } });
    if (!coupon || !coupon.active) throw new ApiError(400, 'Invalid coupon');
    if (coupon.expiresAt && coupon.expiresAt < new Date()) throw new ApiError(400, 'Coupon expired');
    if (coupon.minSpend && subtotal < Number(coupon.minSpend)) {
      throw new ApiError(400, `Minimum spend of ${coupon.minSpend} required`);
    }
    const discount =
      coupon.type === 'PERCENT' ? subtotal * (Number(coupon.value) / 100) : Number(coupon.value);
    res.json({ valid: true, discount });
  } catch (err) {
    next(err);
  }
});

couponRouter.post('/', authenticate, requireRole('VENDOR', 'ADMIN'), async (req, res, next) => {
  try {
    const input = z
      .object({
        code: z.string().min(3),
        type: z.enum(['PERCENT', 'FIXED']),
        value: z.number().positive(),
        minSpend: z.number().optional(),
        usageLimit: z.number().int().optional(),
        expiresAt: z.string().datetime().optional(),
      })
      .parse(req.body);

    let vendorId: string | undefined;
    if (req.user!.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
      vendorId = vendor.id;
    }
    const coupon = await prisma.coupon.create({
      data: {
        ...input,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : undefined,
        vendorId,
      },
    });
    res.status(201).json({ coupon });
  } catch (err) {
    next(err);
  }
});
