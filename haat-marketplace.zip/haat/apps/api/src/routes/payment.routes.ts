import { Router } from 'express';
import { z } from 'zod';
import { authenticate } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';
import * as paymentService from '../services/paymentService';

// Mounted with authentication — initiating payment on an order you own.
export const paymentRouter = Router();
paymentRouter.use(authenticate);

const orderIdSchema = z.object({ orderId: z.string().uuid() });

paymentRouter.post('/stripe/intent', async (req, res, next) => {
  try {
    const { orderId } = orderIdSchema.parse(req.body);
    const result = await paymentService.createStripeIntent(orderId, req.user!.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

paymentRouter.post('/paypal/create', async (req, res, next) => {
  try {
    const { orderId } = orderIdSchema.parse(req.body);
    const result = await paymentService.createPayPalOrder(orderId, req.user!.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

paymentRouter.post('/paypal/capture', async (req, res, next) => {
  try {
    const { paypalOrderId } = z.object({ paypalOrderId: z.string() }).parse(req.body);
    const result = await paymentService.capturePayPalOrder(paypalOrderId);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

paymentRouter.post('/crypto/charge', async (req, res, next) => {
  try {
    const { orderId } = orderIdSchema.parse(req.body);
    const result = await paymentService.createCryptoCharge(orderId, req.user!.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

paymentRouter.get('/bank-transfer/:orderId', async (req, res, next) => {
  try {
    const { orderId } = orderIdSchema.parse({ orderId: req.params.orderId });
    const instructions = await paymentService.getBankTransferInstructions(orderId, req.user!.id);
    res.json(instructions);
  } catch (err) {
    next(err);
  }
});

// Mounted WITHOUT authentication and WITHOUT json body-parsing — gateways
// sign the raw request body, so this router must receive it untouched.
// See app.ts: mounted before `express.json()` with `express.raw(...)`.
export const paymentWebhookRouter = Router();

paymentWebhookRouter.post('/stripe', async (req, res) => {
  const signature = req.headers['stripe-signature'];
  if (typeof signature !== 'string') return res.status(400).send('Missing signature');
  try {
    const event = paymentService.constructStripeEvent(req.body as Buffer, signature);
    await paymentService.handleStripeEvent(event);
    res.json({ received: true });
  } catch (err) {
    res.status(400).send(`Webhook error: ${(err as Error).message}`);
  }
});

paymentWebhookRouter.post('/coinbase', async (req, res) => {
  const signature = req.headers['x-cc-webhook-signature'];
  const rawBody = req.body as Buffer;
  if (typeof signature !== 'string') return res.status(400).send('Missing signature');
  if (!paymentService.verifyCoinbaseSignature(rawBody, signature)) {
    return res.status(400).send('Invalid signature');
  }
  try {
    const parsed = JSON.parse(rawBody.toString('utf8'));
    await paymentService.handleCoinbaseEvent(parsed);
    res.json({ received: true });
  } catch {
    throw new ApiError(400, 'Malformed webhook payload');
  }
});

// PayPal webhook verification requires calling back to PayPal's
// verify-webhook-signature API with the full transmission headers. Stubbed
// here with a TODO — see docs/ROADMAP.md; in the meantime the capture flow
// above confirms payment synchronously on the client's return from PayPal.
paymentWebhookRouter.post('/paypal', async (_req, res) => {
  // TODO: verify via POST https://api-m.paypal.com/v1/notifications/verify-webhook-signature
  res.json({ received: true });
});
