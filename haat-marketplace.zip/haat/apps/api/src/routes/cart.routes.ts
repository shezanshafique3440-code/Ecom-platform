import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate } from '../middleware/authenticate';

export const cartRouter = Router();
cartRouter.use(authenticate);

cartRouter.get('/', async (req, res, next) => {
  try {
    const items = await prisma.cartItem.findMany({
      where: { userId: req.user!.id },
      include: { product: true },
    });
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

const addSchema = z.object({ productId: z.string().uuid(), quantity: z.number().int().min(1).default(1) });

cartRouter.post('/', async (req, res, next) => {
  try {
    const { productId, quantity } = addSchema.parse(req.body);
    const item = await prisma.cartItem.upsert({
      where: { userId_productId: { userId: req.user!.id, productId } },
      update: { quantity: { increment: quantity } },
      create: { userId: req.user!.id, productId, quantity },
    });
    res.status(201).json({ item });
  } catch (err) {
    next(err);
  }
});

cartRouter.patch('/:productId', async (req, res, next) => {
  try {
    const { quantity } = z.object({ quantity: z.number().int().min(1) }).parse(req.body);
    const item = await prisma.cartItem.update({
      where: { userId_productId: { userId: req.user!.id, productId: req.params.productId } },
      data: { quantity },
    });
    res.json({ item });
  } catch (err) {
    next(err);
  }
});

cartRouter.delete('/:productId', async (req, res, next) => {
  try {
    await prisma.cartItem.delete({
      where: { userId_productId: { userId: req.user!.id, productId: req.params.productId } },
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export const wishlistRouter = Router();
wishlistRouter.use(authenticate);

wishlistRouter.get('/', async (req, res, next) => {
  try {
    const items = await prisma.wishlistItem.findMany({
      where: { userId: req.user!.id },
      include: { product: true },
    });
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

wishlistRouter.post('/', async (req, res, next) => {
  try {
    const { productId } = z.object({ productId: z.string().uuid() }).parse(req.body);
    const item = await prisma.wishlistItem.upsert({
      where: { userId_productId: { userId: req.user!.id, productId } },
      update: {},
      create: { userId: req.user!.id, productId },
    });
    res.status(201).json({ item });
  } catch (err) {
    next(err);
  }
});

wishlistRouter.delete('/:productId', async (req, res, next) => {
  try {
    await prisma.wishlistItem.delete({
      where: { userId_productId: { userId: req.user!.id, productId: req.params.productId } },
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
