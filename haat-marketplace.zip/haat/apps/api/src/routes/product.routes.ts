import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';

export const productRouter = Router();

// GET /products — search, filter, sort, paginate (public)
const listQuerySchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  minPrice: z.coerce.number().optional(),
  maxPrice: z.coerce.number().optional(),
  sort: z.enum(['newest', 'price_asc', 'price_desc', 'rating']).optional().default('newest'),
  page: z.coerce.number().int().min(1).optional().default(1),
  pageSize: z.coerce.number().int().min(1).max(60).optional().default(24),
});

productRouter.get('/', async (req, res, next) => {
  try {
    const { q, category, minPrice, maxPrice, sort, page, pageSize } = listQuerySchema.parse(
      req.query,
    );

    const where = {
      status: 'PUBLISHED' as const,
      ...(q ? { title: { contains: q, mode: 'insensitive' as const } } : {}),
      ...(category ? { category: { slug: category } } : {}),
      ...(minPrice || maxPrice
        ? {
            basePrice: {
              ...(minPrice ? { gte: minPrice } : {}),
              ...(maxPrice ? { lte: maxPrice } : {}),
            },
          }
        : {}),
    };

    const orderBy =
      sort === 'price_asc'
        ? { basePrice: 'asc' as const }
        : sort === 'price_desc'
          ? { basePrice: 'desc' as const }
          : sort === 'rating'
            ? { avgRating: 'desc' as const }
            : { createdAt: 'desc' as const };

    const [items, total] = await Promise.all([
      prisma.product.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { vendor: { select: { storeName: true, storeSlug: true } }, category: true },
      }),
      prisma.product.count({ where }),
    ]);

    res.json({ items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) });
  } catch (err) {
    next(err);
  }
});

// GET /products/autocomplete?q= — fast typeahead suggestions
productRouter.get('/autocomplete', async (req, res, next) => {
  try {
    const q = z.string().min(1).parse(req.query.q);
    const items = await prisma.product.findMany({
      where: { status: 'PUBLISHED', title: { contains: q, mode: 'insensitive' } },
      select: { id: true, title: true, slug: true, images: true, basePrice: true },
      take: 8,
    });
    res.json({ items });
  } catch (err) {
    next(err);
  }
});

productRouter.get('/:slug', async (req, res, next) => {
  try {
    const product = await prisma.product.findUnique({
      where: { slug: req.params.slug },
      include: {
        vendor: { select: { storeName: true, storeSlug: true, storeLogoUrl: true } },
        category: true,
        variants: true,
        reviews: { include: { user: { select: { fullName: true, avatarUrl: true } } } },
      },
    });
    if (!product) throw new ApiError(404, 'Product not found');
    res.json({ product });
  } catch (err) {
    next(err);
  }
});

// ---- Vendor-only product management ----

const productInputSchema = z.object({
  title: z.string().min(3),
  slug: z.string().min(3),
  description: z.string().min(10),
  categoryId: z.string().uuid(),
  basePrice: z.number().positive(),
  currency: z.string().default('USD'),
  stock: z.number().int().min(0),
  sku: z.string().min(2),
  images: z.array(z.string().url()).default([]),
});

productRouter.post('/', authenticate, requireRole('VENDOR'), async (req, res, next) => {
  try {
    const input = productInputSchema.parse(req.body);
    const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
    if (vendor.status !== 'APPROVED') {
      throw new ApiError(403, 'Vendor account is not yet approved');
    }
    const product = await prisma.product.create({
      data: { ...input, vendorId: vendor.id, status: 'DRAFT' },
    });
    res.status(201).json({ product });
  } catch (err) {
    next(err);
  }
});

productRouter.patch('/:id', authenticate, requireRole('VENDOR', 'ADMIN'), async (req, res, next) => {
  try {
    const product = await prisma.product.findUniqueOrThrow({ where: { id: req.params.id } });
    if (req.user!.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
      if (product.vendorId !== vendor.id) throw new ApiError(403, 'Not your product');
    }
    const updates = productInputSchema.partial().parse(req.body);
    const updated = await prisma.product.update({ where: { id: product.id }, data: updates });
    res.json({ product: updated });
  } catch (err) {
    next(err);
  }
});

productRouter.delete('/:id', authenticate, requireRole('VENDOR', 'ADMIN'), async (req, res, next) => {
  try {
    const product = await prisma.product.findUniqueOrThrow({ where: { id: req.params.id } });
    if (req.user!.role === 'VENDOR') {
      const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
      if (product.vendorId !== vendor.id) throw new ApiError(403, 'Not your product');
    }
    await prisma.product.delete({ where: { id: product.id } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
