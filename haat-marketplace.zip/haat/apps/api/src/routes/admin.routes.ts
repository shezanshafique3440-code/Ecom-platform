import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';

export const adminRouter = Router();
adminRouter.use(authenticate, requireRole('ADMIN'));

// ---- Dashboard analytics ----
adminRouter.get('/analytics/overview', async (_req, res, next) => {
  try {
    const [userCount, vendorCount, orderCount, productCount, revenue] = await Promise.all([
      prisma.user.count(),
      prisma.vendor.count({ where: { status: 'APPROVED' } }),
      prisma.order.count(),
      prisma.product.count({ where: { status: 'PUBLISHED' } }),
      prisma.order.aggregate({ _sum: { grandTotal: true }, where: { status: { not: 'CANCELLED' } } }),
    ]);
    res.json({
      userCount,
      vendorCount,
      orderCount,
      productCount,
      totalRevenue: revenue._sum.grandTotal ?? 0,
    });
  } catch (err) {
    next(err);
  }
});

// ---- User management ----
adminRouter.get('/users', async (req, res, next) => {
  try {
    const role = z.enum(['CUSTOMER', 'VENDOR', 'ADMIN', 'SUPPORT_AGENT']).optional().parse(
      req.query.role,
    );
    const users = await prisma.user.findMany({
      where: role ? { role } : undefined,
      select: { id: true, email: true, fullName: true, role: true, status: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ users });
  } catch (err) {
    next(err);
  }
});

adminRouter.patch('/users/:id/status', async (req, res, next) => {
  try {
    const { status } = z
      .object({ status: z.enum(['ACTIVE', 'SUSPENDED']) })
      .parse(req.body);
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { status },
      select: { id: true, email: true, status: true },
    });
    res.json({ user });
  } catch (err) {
    next(err);
  }
});

// ---- Category management ----
adminRouter.post('/categories', async (req, res, next) => {
  try {
    const input = z
      .object({ name: z.string().min(2), slug: z.string().min(2), parentId: z.string().uuid().optional(), imageUrl: z.string().url().optional() })
      .parse(req.body);
    const category = await prisma.category.create({ data: input });
    res.status(201).json({ category });
  } catch (err) {
    next(err);
  }
});

adminRouter.get('/categories', async (_req, res, next) => {
  try {
    const categories = await prisma.category.findMany({ include: { children: true } });
    res.json({ categories });
  } catch (err) {
    next(err);
  }
});

// ---- Banner management ----
adminRouter.post('/banners', async (req, res, next) => {
  try {
    const input = z
      .object({
        title: z.string(),
        imageUrl: z.string().url(),
        linkUrl: z.string().url().optional(),
        position: z.string().default('HOME_HERO'),
      })
      .parse(req.body);
    const banner = await prisma.banner.create({ data: input });
    res.status(201).json({ banner });
  } catch (err) {
    next(err);
  }
});

adminRouter.get('/banners', async (_req, res, next) => {
  try {
    const banners = await prisma.banner.findMany({ where: { active: true } });
    res.json({ banners });
  } catch (err) {
    next(err);
  }
});

// ---- CMS pages ----
adminRouter.post('/cms', async (req, res, next) => {
  try {
    const input = z.object({ slug: z.string(), title: z.string(), content: z.string() }).parse(req.body);
    const page = await prisma.cmsPage.upsert({
      where: { slug: input.slug },
      update: { title: input.title, content: input.content },
      create: input,
    });
    res.json({ page });
  } catch (err) {
    next(err);
  }
});

// ---- Security logs ----
adminRouter.get('/security-logs', async (req, res, next) => {
  try {
    const logs = await prisma.securityLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 200,
      include: { user: { select: { email: true } } },
    });
    res.json({ logs });
  } catch (err) {
    next(err);
  }
});

// ---- Payment oversight ----
adminRouter.get('/payments', async (_req, res, next) => {
  try {
    const payments = await prisma.payment.findMany({
      orderBy: { createdAt: 'desc' },
      include: { order: { select: { orderNumber: true, userId: true } } },
      take: 200,
    });
    res.json({ payments });
  } catch (err) {
    next(err);
  }
});
