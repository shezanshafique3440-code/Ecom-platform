import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';

export const supportRouter = Router();
supportRouter.use(authenticate);

supportRouter.post('/tickets', async (req, res, next) => {
  try {
    const { subject, message } = z
      .object({ subject: z.string().min(3), message: z.string().min(1) })
      .parse(req.body);
    const ticket = await prisma.supportTicket.create({
      data: {
        subject,
        customerId: req.user!.id,
        messages: { create: { senderId: req.user!.id, body: message } },
      },
      include: { messages: true },
    });
    res.status(201).json({ ticket });
  } catch (err) {
    next(err);
  }
});

supportRouter.get('/tickets/mine', async (req, res, next) => {
  try {
    const tickets = await prisma.supportTicket.findMany({
      where: { customerId: req.user!.id },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ tickets });
  } catch (err) {
    next(err);
  }
});

supportRouter.get('/tickets/:id/messages', async (req, res, next) => {
  try {
    const ticket = await prisma.supportTicket.findUniqueOrThrow({ where: { id: req.params.id } });
    if (
      ticket.customerId !== req.user!.id &&
      req.user!.role !== 'SUPPORT_AGENT' &&
      req.user!.role !== 'ADMIN'
    ) {
      throw new ApiError(403, 'Not your ticket');
    }
    const messages = await prisma.chatMessage.findMany({
      where: { ticketId: ticket.id },
      orderBy: { createdAt: 'asc' },
      include: { sender: { select: { fullName: true, role: true, avatarUrl: true } } },
    });
    res.json({ messages });
  } catch (err) {
    next(err);
  }
});

supportRouter.post('/tickets/:id/messages', async (req, res, next) => {
  try {
    const { body, attachmentUrl } = z
      .object({ body: z.string().optional(), attachmentUrl: z.string().url().optional() })
      .parse(req.body);
    const message = await prisma.chatMessage.create({
      data: { ticketId: req.params.id, senderId: req.user!.id, body, attachmentUrl },
    });
    // Real-time delivery happens over the WS gateway (see src/realtime/chatGateway.ts),
    // which broadcasts this event to the other participant's socket.
    res.status(201).json({ message });
  } catch (err) {
    next(err);
  }
});

// ---- Agent dashboard ----
supportRouter.get('/agent/queue', requireRole('SUPPORT_AGENT', 'ADMIN'), async (_req, res, next) => {
  try {
    const tickets = await prisma.supportTicket.findMany({
      where: { status: { in: ['OPEN', 'IN_PROGRESS'] } },
      include: { customer: { select: { fullName: true, email: true } } },
      orderBy: { createdAt: 'asc' },
    });
    res.json({ tickets });
  } catch (err) {
    next(err);
  }
});

supportRouter.patch('/tickets/:id/claim', requireRole('SUPPORT_AGENT', 'ADMIN'), async (req, res, next) => {
  try {
    const ticket = await prisma.supportTicket.update({
      where: { id: req.params.id },
      data: { agentId: req.user!.id, status: 'IN_PROGRESS' },
    });
    res.json({ ticket });
  } catch (err) {
    next(err);
  }
});

supportRouter.patch('/tickets/:id/resolve', requireRole('SUPPORT_AGENT', 'ADMIN'), async (req, res, next) => {
  try {
    const ticket = await prisma.supportTicket.update({
      where: { id: req.params.id },
      data: { status: 'RESOLVED' },
    });
    res.json({ ticket });
  } catch (err) {
    next(err);
  }
});
