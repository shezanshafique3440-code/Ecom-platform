import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';
import * as orderService from '../services/orderService';

export const orderRouter = Router();
orderRouter.use(authenticate);

const checkoutSchema = z.object({
  shippingAddressId: z.string().uuid().optional(),
  couponCode: z.string().optional(),
  paymentMethod: z.enum(['STRIPE', 'PAYPAL', 'BANK_TRANSFER', 'CRYPTO', 'COD']),
});

orderRouter.post('/checkout', async (req, res, next) => {
  try {
    const input = checkoutSchema.parse(req.body);
    const order = await orderService.checkout({ userId: req.user!.id, ...input });
    // TODO: dispatch to payment gateway (Stripe PaymentIntent / PayPal order
    // / bank transfer instructions / crypto invoice) based on input.paymentMethod.
    res.status(201).json({ order });
  } catch (err) {
    next(err);
  }
});

orderRouter.get('/', async (req, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
      include: { items: { include: { product: true } }, payment: true },
    });
    res.json({ orders });
  } catch (err) {
    next(err);
  }
});

orderRouter.get('/:id/tracking', async (req, res, next) => {
  try {
    const order = await prisma.order.findUniqueOrThrow({ where: { id: req.params.id } });
    if (order.userId !== req.user!.id && req.user!.role !== 'ADMIN') {
      throw new ApiError(403, 'Not your order');
    }
    const events = await prisma.orderTrackingEvent.findMany({
      where: { orderId: order.id },
      orderBy: { createdAt: 'asc' },
    });
    res.json({ order, events });
  } catch (err) {
    next(err);
  }
});

// Vendor: view + update orders containing their products
orderRouter.get('/vendor/mine', requireRole('VENDOR'), async (req, res, next) => {
  try {
    const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
    const groups = await prisma.orderVendorGroup.findMany({
      where: { vendorId: vendor.id },
      include: { order: { include: { items: true } } },
      orderBy: { order: { createdAt: 'desc' } },
    });
    res.json({ groups });
  } catch (err) {
    next(err);
  }
});

orderRouter.patch(
  '/vendor/:orderId/status',
  requireRole('VENDOR', 'ADMIN'),
  async (req, res, next) => {
    try {
      const { status, note } = z
        .object({
          status: z.enum(['CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED']),
          note: z.string().optional(),
        })
        .parse(req.body);

      if (req.user!.role === 'VENDOR') {
        const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
        await prisma.orderVendorGroup.updateMany({
          where: { orderId: req.params.orderId, vendorId: vendor.id },
          data: { status },
        });
      }

      await prisma.orderTrackingEvent.create({
        data: { orderId: req.params.orderId, status, note },
      });

      res.json({ success: true });
    } catch (err) {
      next(err);
    }
  },
);
