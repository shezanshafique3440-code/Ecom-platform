import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { authenticate, requireRole } from '../middleware/authenticate';
import { ApiError } from '../middleware/errorHandler';

export const vendorRouter = Router();

// Public: storefront view of an approved vendor
vendorRouter.get('/:slug', async (req, res, next) => {
  try {
    const vendor = await prisma.vendor.findUniqueOrThrow({
      where: { storeSlug: req.params.slug },
      include: { products: { where: { status: 'PUBLISHED' } } },
    });
    if (vendor.status !== 'APPROVED') throw new ApiError(404, 'Store not found');
    res.json({ vendor });
  } catch (err) {
    next(err);
  }
});

vendorRouter.use(authenticate);

const applySchema = z.object({
  storeName: z.string().min(2),
  storeSlug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  description: z.string().optional(),
});

vendorRouter.post('/apply', async (req, res, next) => {
  try {
    const input = applySchema.parse(req.body);
    const existing = await prisma.vendor.findUnique({ where: { userId: req.user!.id } });
    if (existing) throw new ApiError(409, 'You already have a vendor application');

    const vendor = await prisma.vendor.create({
      data: { ...input, userId: req.user!.id, status: 'PENDING' },
    });
    await prisma.user.update({ where: { id: req.user!.id }, data: { role: 'VENDOR' } });
    res.status(201).json({ vendor });
  } catch (err) {
    next(err);
  }
});

// Vendor dashboard: sales analytics + earnings summary
vendorRouter.get('/dashboard/summary', requireRole('VENDOR'), async (req, res, next) => {
  try {
    const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
    const groups = await prisma.orderVendorGroup.findMany({ where: { vendorId: vendor.id } });

    const totalSales = groups.reduce((s, g) => s + Number(g.subtotal), 0);
    const totalPayout = groups.reduce((s, g) => s + Number(g.payout), 0);
    const totalCommission = groups.reduce((s, g) => s + Number(g.commission), 0);
    const orderCount = groups.length;
    const productCount = await prisma.product.count({ where: { vendorId: vendor.id } });
    const lowStock = await prisma.product.count({
      where: { vendorId: vendor.id, stock: { lte: 5 } },
    });

    res.json({
      totalSales,
      totalPayout,
      totalCommission,
      orderCount,
      productCount,
      lowStock,
    });
  } catch (err) {
    next(err);
  }
});

vendorRouter.post('/withdrawals', requireRole('VENDOR'), async (req, res, next) => {
  try {
    const { amount, method } = z
      .object({ amount: z.number().positive(), method: z.string() })
      .parse(req.body);
    const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
    const request = await prisma.withdrawalRequest.create({
      data: { vendorId: vendor.id, amount, method },
    });
    res.status(201).json({ request });
  } catch (err) {
    next(err);
  }
});

vendorRouter.get('/withdrawals/mine', requireRole('VENDOR'), async (req, res, next) => {
  try {
    const vendor = await prisma.vendor.findUniqueOrThrow({ where: { userId: req.user!.id } });
    const requests = await prisma.withdrawalRequest.findMany({
      where: { vendorId: vendor.id },
      orderBy: { requestedAt: 'desc' },
    });
    res.json({ requests });
  } catch (err) {
    next(err);
  }
});

// ---- Admin: vendor approval workflow ----

vendorRouter.get('/', requireRole('ADMIN'), async (req, res, next) => {
  try {
    const status = z.enum(['PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED']).optional().parse(
      req.query.status,
    );
    const vendors = await prisma.vendor.findMany({
      where: status ? { status } : undefined,
      include: { user: { select: { email: true, fullName: true } } },
      orderBy: { createdAt: 'desc' },
    });
    res.json({ vendors });
  } catch (err) {
    next(err);
  }
});

vendorRouter.patch('/:id/status', requireRole('ADMIN'), async (req, res, next) => {
  try {
    const { status } = z
      .object({ status: z.enum(['APPROVED', 'REJECTED', 'SUSPENDED']) })
      .parse(req.body);
    const vendor = await prisma.vendor.update({
      where: { id: req.params.id },
      data: { status, approvedAt: status === 'APPROVED' ? new Date() : undefined },
    });
    // TODO: send VENDOR_APPROVED / VENDOR_REJECTED email via EmailTemplate.
    res.json({ vendor });
  } catch (err) {
    next(err);
  }
});

vendorRouter.patch(
  '/withdrawals/:id/process',
  requireRole('ADMIN'),
  async (req, res, next) => {
    try {
      const { status, notes } = z
        .object({ status: z.enum(['APPROVED', 'REJECTED', 'PAID']), notes: z.string().optional() })
        .parse(req.body);
      const request = await prisma.withdrawalRequest.update({
        where: { id: req.params.id },
        data: { status, notes, processedAt: new Date() },
      });
      res.json({ request });
    } catch (err) {
      next(err);
    }
  },
);
