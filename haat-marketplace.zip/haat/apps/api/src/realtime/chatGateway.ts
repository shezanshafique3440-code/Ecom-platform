import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { verifyAccessToken } from '../utils/auth';

// Maps userId -> active sockets (a user may have multiple tabs/devices open)
const connections = new Map<string, Set<WebSocket>>();

export function initChatGateway(server: Server): void {
  const wss = new WebSocketServer({ server, path: '/ws/chat' });

  wss.on('connection', (socket, req) => {
    const url = new URL(req.url ?? '', 'http://localhost');
    const token = url.searchParams.get('token');
    if (!token) {
      socket.close(4001, 'Missing auth token');
      return;
    }
    let userId: string;
    try {
      userId = verifyAccessToken(token).sub;
    } catch {
      socket.close(4001, 'Invalid auth token');
      return;
    }

    if (!connections.has(userId)) connections.set(userId, new Set());
    connections.get(userId)!.add(socket);

    socket.on('close', () => {
      connections.get(userId)?.delete(socket);
    });
  });
}

// Called from support.routes.ts after persisting a chat message, to push it
// to the recipient's open sockets in real time.
export function pushToUser(userId: string, payload: unknown): void {
  const sockets = connections.get(userId);
  if (!sockets) return;
  const data = JSON.stringify(payload);
  for (const socket of sockets) {
    if (socket.readyState === WebSocket.OPEN) socket.send(data);
  }
}
