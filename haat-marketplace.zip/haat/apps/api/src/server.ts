import http from 'http';
import { createApp } from './app';
import { initChatGateway } from './realtime/chatGateway';
import { env } from './config/env';

const app = createApp();
const server = http.createServer(app);

initChatGateway(server);

server.listen(env.port, () => {
  // eslint-disable-next-line no-console
  console.log(`Haat API listening on :${env.port} [${env.nodeEnv}]`);
});
