import express from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import pinoHttp from 'pino-http';

import { securityHeaders, corsPolicy, apiRateLimit, sanitizeInput } from './middleware/security';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';

import { authRouter } from './routes/auth.routes';
import { productRouter } from './routes/product.routes';
import { cartRouter, wishlistRouter } from './routes/cart.routes';
import { orderRouter } from './routes/order.routes';
import { vendorRouter } from './routes/vendor.routes';
import { reviewRouter, couponRouter } from './routes/catalogExtras.routes';
import { adminRouter } from './routes/admin.routes';
import { supportRouter } from './routes/support.routes';

export function createApp() {
  const app = express();

  app.set('trust proxy', 1); // required for correct req.ip behind Nginx/CDN

  app.use(pinoHttp({ redact: ['req.headers.authorization', 'req.headers.cookie'] }));
  app.use(securityHeaders);
  app.use(corsPolicy);
  app.use(compression());
  app.use(express.json({ limit: '2mb' }));
  app.use(cookieParser());
  app.use(sanitizeInput);
  app.use(apiRateLimit);

  // Note on CSRF: cookie-based refresh tokens use SameSite=Strict + Secure,
  // which is the primary CSRF defense for this API. State-changing routes
  // additionally require a Bearer access token that a cross-site page
  // cannot read, so the double-submit CSRF token (csrf-csrf) is applied
  // only to the cookie-only /auth/refresh endpoint in production — see
  // docs/ARCHITECTURE.md#csrf for the full rationale.

  app.get('/health', (_req, res) => res.json({ status: 'ok' }));

  app.use('/api/auth', authRouter);
  app.use('/api/products', productRouter);
  app.use('/api/cart', cartRouter);
  app.use('/api/wishlist', wishlistRouter);
  app.use('/api/orders', orderRouter);
  app.use('/api/vendors', vendorRouter);
  app.use('/api/reviews', reviewRouter);
  app.use('/api/coupons', couponRouter);
  app.use('/api/admin', adminRouter);
  app.use('/api/support', supportRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
